package chat.server.iface;

public class ChatPerson {
	
	public String nickname;

	public ChatPerson() {
		super();
	}
	
	public ChatPerson(String nickname) {
		this.nickname = nickname;	
	}

}
